/**
 * Main JavaScript File for My Professional Theme
 * Pure Vanilla JavaScript for interactivity, mobile menu, search modal & post interactions.
 */

document.addEventListener('DOMContentLoaded', () => {
  // Mobile Navigation Drawer Toggle
  const mobileToggle = document.querySelector('.mobile-nav-toggle');
  const mobileDrawer = document.querySelector('.mobile-drawer');
  const mobileClose = document.querySelector('.mobile-drawer-close');

  if (mobileToggle && mobileDrawer) {
    mobileToggle.addEventListener('click', () => {
      mobileDrawer.classList.add('active');
      document.body.style.overflow = 'hidden';
    });

    if (mobileClose) {
      mobileClose.addEventListener('click', () => {
        mobileDrawer.classList.remove('active');
        document.body.style.overflow = '';
      });
    }

    mobileDrawer.addEventListener('click', (e) => {
      if (e.target === mobileDrawer) {
        mobileDrawer.classList.remove('active');
        document.body.style.overflow = '';
      }
    });
  }

  // Search Modal Trigger & Modal Controls
  const searchTriggers = document.querySelectorAll('.btn-search-trigger');
  const searchModal = document.querySelector('.search-modal');
  const searchClose = document.querySelector('.search-modal-close');
  const searchInput = document.querySelector('.search-modal input[type="search"]');

  if (searchTriggers.length && searchModal) {
    searchTriggers.forEach((trigger) => {
      trigger.addEventListener('click', (e) => {
        e.preventDefault();
        searchModal.classList.add('active');
        document.body.style.overflow = 'hidden';
        if (searchInput) searchInput.focus();
      });
    });

    if (searchClose) {
      searchClose.addEventListener('click', () => {
        searchModal.classList.remove('active');
        document.body.style.overflow = '';
      });
    }

    window.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && searchModal.classList.contains('active')) {
        searchModal.classList.remove('active');
        document.body.style.overflow = '';
      }
    });
  }

  // Headline Slider Auto-Cycle (if multiple slides present)
  const sliderItems = document.querySelectorAll('.headline-slider-item');
  if (sliderItems.length > 1) {
    let currentIndex = 0;
    setInterval(() => {
      sliderItems[currentIndex].style.display = 'none';
      currentIndex = (currentIndex + 1) % sliderItems.length;
      sliderItems[currentIndex].style.display = 'flex';
    }, 5000);
  }

  // Post Reaction Buttons (Client-side interactive storage)
  const reactionButtons = document.querySelectorAll('.reaction-btn');
  reactionButtons.forEach((btn) => {
    btn.addEventListener('click', function () {
      const type = this.getAttribute('data-reaction');
      const countEl = this.querySelector('.count');
      let currentCount = parseInt(countEl.textContent, 10) || 0;

      if (this.classList.contains('active')) {
        this.classList.remove('active');
        countEl.textContent = Math.max(0, currentCount - 1);
      } else {
        this.classList.add('active');
        countEl.textContent = currentCount + 1;
      }
    });
  });

  // Copy Link Handler
  const copyBtns = document.querySelectorAll('.btn-copy-link');
  copyBtns.forEach((btn) => {
    btn.addEventListener('click', function () {
      const url = this.getAttribute('data-url') || window.location.href;
      navigator.clipboard.writeText(url).then(() => {
        const origText = this.innerHTML;
        this.innerHTML = '✓ Kopyalandı!';
        setTimeout(() => {
          this.innerHTML = origText;
        }, 2000);
      });
    });
  });
});
