<?php
/**
 * Comments Template File (comments.php)
 *
 * @package My_Professional_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( post_password_required() ) {
	return;
}
?>

<div id="comments" class="comments-area">

	<?php if ( have_comments() ) : ?>
		<h2 class="comments-title">
			<?php
			$my_theme_comment_count = get_comments_number();
			if ( '1' === $my_theme_comment_count ) {
				printf(
					/* translators: 1: title. */
					esc_html__( '1 Yorum "%1$s"', 'my-theme' ),
					'<span>' . wp_kses_post( get_the_title() ) . '</span>'
				);
			} else {
				printf(
					/* translators: 1: comment count, 2: title. */
					esc_html( _nx( '%1$s Yorum "%2$s"', '%1$s Yorum "%2$s"', $my_theme_comment_count, 'comments title', 'my-theme' ) ),
					number_format_i18n( $my_theme_comment_count ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					'<span>' . wp_kses_post( get_the_title() ) . '</span>'
				);
			}
			?>
		</h2>

		<ol class="comment-list">
			<?php
			wp_list_comments(
				array(
					'style'       => 'ol',
					'short_ping'  => true,
					'avatar_size' => 48,
				)
			);
			?>
		</ol>

		<?php
		the_comments_navigation();

		if ( ! comments_open() ) :
			?>
			<p class="no-comments"><?php esc_html_e( 'Yorumlar bu yazı için kapatılmıştır.', 'my-theme' ); ?></p>
			<?php
		endif;

	endif;

	comment_form(
		array(
			'title_reply'       => __( 'Bir Yorum Bırakın', 'my-theme' ),
			'title_reply_to'    => __( '%s Kişisine Yanıt Verin', 'my-theme' ),
			'class_submit'      => 'submit-btn',
			'label_submit'      => __( 'Yorumu Gönder', 'my-theme' ),
			'comment_field'     => '<p class="comment-form-comment"><label for="comment">' . _x( 'Yorumunuz', 'noun', 'my-theme' ) . '</label><textarea id="comment" name="comment" cols="45" rows="5" required></textarea></p>',
		)
	);
	?>

</div>
