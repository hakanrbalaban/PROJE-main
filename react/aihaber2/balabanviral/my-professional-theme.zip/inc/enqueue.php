<?php
/**
 * Script & Style Enqueue Logic
 *
 * @package My_Professional_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Enqueue Theme Scripts and Styles
 */
function my_theme_enqueue_assets() {
	$theme_version = wp_get_theme()->get( 'Version' );

	// Enqueue Google Fonts (Syne, Literata, DM Sans).
	wp_enqueue_style(
		'my-theme-fonts',
		'https://fonts.googleapis.com/css2?family=DM+Sans:ital,opsz,wght@0,9..40,100..1000;1,9..40,100..1000&family=Literata:ital,opsz,wght@0,7..72,200..900;1,7..72,200..900&family=Syne:wght@400..800&display=swap',
		array(),
		null
	);

	// Enqueue Main Compiled CSS.
	wp_enqueue_style(
		'my-theme-main-style',
		get_template_directory_uri() . '/assets/css/main.css',
		array( 'my-theme-fonts' ),
		$theme_version
	);

	// Enqueue Core style.css for WordPress requirements.
	wp_enqueue_style(
		'my-theme-style',
		get_stylesheet_uri(),
		array( 'my-theme-main-style' ),
		$theme_version
	);

	// Enqueue Main Vanilla JavaScript.
	wp_enqueue_script(
		'my-theme-main-js',
		get_template_directory_uri() . '/assets/js/main.js',
		array(),
		$theme_version,
		true
	);

	// Enqueue Comment reply script on single pages if enabled.
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'my_theme_enqueue_assets' );
