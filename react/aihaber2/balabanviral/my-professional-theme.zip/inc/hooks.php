<?php
/**
 * Action & Filter Hooks
 *
 * @package My_Professional_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Filter Excerpt Length
 *
 * @param int $length Excerpt word count.
 * @return int Modified length.
 */
function my_theme_custom_excerpt_length( $length ) {
	return 22;
}
add_filter( 'excerpt_length', 'my_theme_custom_excerpt_length', 999 );

/**
 * Filter Excerpt More Readability String
 *
 * @param string $more Default more text.
 * @return string Modified more text.
 */
function my_theme_excerpt_more( $more ) {
	return '...';
}
add_filter( 'excerpt_more', 'my_theme_excerpt_more' );

/**
 * Add Custom Body Classes
 *
 * @param array $classes Existing body classes.
 * @return array Modified body classes.
 */
function my_theme_body_classes( $classes ) {
	$classes[] = 'dark-theme-active';

	if ( is_singular() ) {
		$classes[] = 'singular-post-view';
	}

	return $classes;
}
add_filter( 'body_class', 'my_theme_body_classes' );

/**
 * Pingback Header Meta Hook
 */
function my_theme_pingback_header() {
	if ( is_singular() && pings_open() ) {
		printf( '<link rel="pingback" href="%s">', esc_url( get_bloginfo( 'pingback_url' ) ) );
	}
}
add_action( 'wp_head', 'my_theme_pingback_header' );
