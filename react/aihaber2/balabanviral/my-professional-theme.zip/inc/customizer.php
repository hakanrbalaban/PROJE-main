<?php
/**
 * WordPress Customizer Settings & Controls
 *
 * @package My_Professional_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register Customizer settings and controls.
 *
 * @param WP_Customize_Manager $wp_customize Customizer Manager object.
 */
function my_theme_customize_register( $wp_customize ) {

	// Panel: Theme Settings
	$wp_customize->add_panel(
		'my_theme_options_panel',
		array(
			'title'       => __( 'Theme Options', 'my-theme' ),
			'description' => __( 'Customize theme layouts, hero section, social channels, and footer information.', 'my-theme' ),
			'priority'    => 30,
		)
	);

	// Section: Hero & Headline Slider
	$wp_customize->add_section(
		'my_theme_hero_section',
		array(
			'title'    => __( 'Hero & Headline Slider', 'my-theme' ),
			'panel'    => 'my_theme_options_panel',
			'priority' => 10,
		)
	);

	// Setting: Show Hero Slider
	$wp_customize->add_setting(
		'my_theme_show_hero',
		array(
			'default'           => true,
			'sanitize_callback' => 'my_theme_sanitize_checkbox',
		)
	);

	$wp_customize->add_control(
		'my_theme_show_hero',
		array(
			'label'    => __( 'Enable Hero Slider on Homepage', 'my-theme' ),
			'section'  => 'my_theme_hero_section',
			'type'     => 'checkbox',
			'priority' => 10,
		)
	);

	// Setting: Ticker Headline Text
	$wp_customize->add_setting(
		'my_theme_ticker_label',
		array(
			'default'           => __( 'Öne Çıkan Haberler', 'my-theme' ),
			'sanitize_callback' => 'sanitize_text_field',
		)
	);

	$wp_customize->add_control(
		'my_theme_ticker_label',
		array(
			'label'    => __( 'Ticker Badge Label', 'my-theme' ),
			'section'  => 'my_theme_hero_section',
			'type'     => 'text',
			'priority' => 20,
		)
	);

	// Section: Social Links
	$wp_customize->add_section(
		'my_theme_social_section',
		array(
			'title'    => __( 'Social Media Links', 'my-theme' ),
			'panel'    => 'my_theme_options_panel',
			'priority' => 20,
		)
	);

	$social_services = array(
		'twitter'   => __( 'Twitter / X URL', 'my-theme' ),
		'instagram' => __( 'Instagram URL', 'my-theme' ),
		'youtube'   => __( 'YouTube URL', 'my-theme' ),
		'telegram'  => __( 'Telegram URL', 'my-theme' ),
		'linkedin'  => __( 'LinkedIn URL', 'my-theme' ),
	);

	foreach ( $social_services as $id => $label ) {
		$wp_customize->add_setting(
			"my_theme_social_{$id}",
			array(
				'default'           => '',
				'sanitize_callback' => 'esc_url_raw',
			)
		);

		$wp_customize->add_control(
			"my_theme_social_{$id}",
			array(
				'label'   => $label,
				'section' => 'my_theme_social_section',
				'type'    => 'url',
			)
		);
	}

	// Section: Footer Options
	$wp_customize->add_section(
		'my_theme_footer_section',
		array(
			'title'    => __( 'Footer Settings', 'my-theme' ),
			'panel'    => 'my_theme_options_panel',
			'priority' => 30,
		)
	);

	// Setting: Copyright Text
	$wp_customize->add_setting(
		'my_theme_copyright_text',
		array(
			'default'           => sprintf( __( '© %s Tüm Hakları Saklıdır.', 'my-theme' ), date( 'Y' ) ),
			'sanitize_callback' => 'wp_kses_post',
		)
	);

	$wp_customize->add_control(
		'my_theme_copyright_text',
		array(
			'label'    => __( 'Footer Copyright Text', 'my-theme' ),
			'section'  => 'my_theme_footer_section',
			'type'     => 'textarea',
			'priority' => 10,
		)
	);
}
add_action( 'customize_register', 'my_theme_customize_register' );

/**
 * Sanitize Checkbox
 *
 * @param bool $checked Input status.
 * @return bool
 */
function my_theme_sanitize_checkbox( $checked ) {
	return ( isset( $checked ) && true === (bool) $checked );
}
