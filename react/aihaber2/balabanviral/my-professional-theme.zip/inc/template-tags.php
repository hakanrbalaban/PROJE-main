<?php
/**
 * Custom Template Tags
 *
 * @package My_Professional_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'my_theme_posted_on' ) ) :
	/**
	 * Output HTML with meta information for the current post date.
	 */
	function my_theme_posted_on() {
		$time_string = '<time class="entry-date published updated" datetime="%1$s">%2$s</time>';
		if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
			$time_string = '<time class="entry-date published" datetime="%1$s">%2$s</time>';
		}

		$time_string = sprintf(
			$time_string,
			esc_attr( get_the_date( DATE_W3C ) ),
			esc_html( get_the_date() )
		);

		echo '<span class="posted-on">📅 ' . $time_string . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
endif;

if ( ! function_exists( 'my_theme_posted_by' ) ) :
	/**
	 * Output HTML with meta information for the current author.
	 */
	function my_theme_posted_by() {
		$byline = sprintf(
			/* translators: %s: post author. */
			esc_html_x( 'Yazar: %s', 'post author', 'my-theme' ),
			'<span class="author vcard"><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '">' . esc_html( get_the_author() ) . '</a></span>'
		);

		echo '<span class="byline">👤 ' . $byline . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
endif;

if ( ! function_exists( 'my_theme_category_badge' ) ) :
	/**
	 * Render First Category Badge
	 */
	function my_theme_category_badge() {
		$categories = get_the_category();
		if ( ! empty( $categories ) ) {
			$cat = $categories[0];
			echo '<a href="' . esc_url( get_category_link( $cat->term_id ) ) . '" class="category-badge">' . esc_html( $cat->name ) . '</a>';
		}
	}
endif;

if ( ! function_exists( 'my_theme_post_thumbnail' ) ) :
	/**
	 * Display Post Thumbnail with Fallback
	 *
	 * @param string $size Image size.
	 */
	function my_theme_post_thumbnail( $size = 'my-theme-grid' ) {
		if ( post_password_required() || is_attachment() ) {
			return;
		}

		if ( has_post_thumbnail() ) {
			the_post_thumbnail( $size, array( 'loading' => 'lazy' ) );
		} else {
			echo '<img src="' . esc_url( my_theme_get_fallback_image() ) . '" alt="' . esc_attr( get_the_title() ) . '" loading="lazy" />';
		}
	}
endif;
