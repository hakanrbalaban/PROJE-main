<?php
/**
 * Helper PHP Functions
 *
 * @package My_Professional_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Calculate Estimated Reading Time in Minutes
 *
 * @param int $post_id Post ID.
 * @return int Reading time in minutes.
 */
function my_theme_estimate_reading_time( $post_id = null ) {
	$content    = get_post_field( 'post_content', $post_id );
	$word_count = str_word_count( wp_strip_all_tags( $content ) );
	$wpm        = 200; // Words per minute rate
	$minutes    = ceil( $word_count / $wpm );

	return max( 1, $minutes );
}

/**
 * Track and Increment Post Views
 *
 * @param int $post_id Post ID.
 */
function my_theme_set_post_views( $post_id ) {
	$count_key = 'my_theme_post_views_count';
	$count     = get_post_meta( $post_id, $count_key, true );

	if ( '' === $count ) {
		$count = 0;
		delete_post_meta( $post_id, $count_key );
		add_post_meta( $post_id, $count_key, '1' );
	} else {
		$count++;
		update_post_meta( $post_id, $count_key, $count );
	}
}

/**
 * Get Post Views Count
 *
 * @param int $post_id Post ID.
 * @return int View count.
 */
function my_theme_get_post_views( $post_id ) {
	$count_key = 'my_theme_post_views_count';
	$count     = get_post_meta( $post_id, $count_key, true );

	if ( '' === $count ) {
		return 0;
	}

	return (int) $count;
}

/**
 * Get Fallback Image URL if Post Thumbnail does not exist
 *
 * @return string Image URL.
 */
function my_theme_get_fallback_image() {
	return get_template_directory_uri() . '/assets/images/default-banner.jpg';
}
