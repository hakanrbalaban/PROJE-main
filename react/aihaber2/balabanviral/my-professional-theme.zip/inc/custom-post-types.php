<?php
/**
 * Custom Post Types & Custom Taxonomies Registration
 *
 * @package My_Professional_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register Headline/Manşet Custom Post Type
 */
function my_theme_register_cpts() {
	$labels = array(
		'name'                  => _x( 'Manşetler', 'Post Type General Name', 'my-theme' ),
		'singular_name'         => _x( 'Manşet', 'Post Type Singular Name', 'my-theme' ),
		'menu_name'             => __( 'Manşetler', 'my-theme' ),
		'name_admin_bar'        => __( 'Manşet', 'my-theme' ),
		'archives'              => __( 'Manşet Arşivi', 'my-theme' ),
		'attributes'            => __( 'Manşet Özellikleri', 'my-theme' ),
		'all_items'             => __( 'Tüm Manşetler', 'my-theme' ),
		'add_new_item'          => __( 'Yeni Manşet Ekle', 'my-theme' ),
		'add_new'               => __( 'Yeni Ekle', 'my-theme' ),
		'new_item'              => __( 'Yeni Manşet', 'my-theme' ),
		'edit_item'             => __( 'Manşeti Düzenle', 'my-theme' ),
		'update_item'           => __( 'Manşeti Güncelle', 'my-theme' ),
		'view_item'             => __( 'Manşeti Görüntüle', 'my-theme' ),
		'search_items'          => __( 'Manşet Ara', 'my-theme' ),
		'not_found'             => __( 'Manşet Bulunamadı', 'my-theme' ),
		'not_found_in_trash'    => __( 'Çöpte Manşet Bulunamadı', 'my-theme' ),
	);

	$args = array(
		'label'                 => __( 'Manşet', 'my-theme' ),
		'description'           => __( 'Ana sayfadaki öne çıkan büyük manşetler', 'my-theme' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields', 'revisions' ),
		'taxonomies'            => array( 'category', 'post_tag' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'             => 'dashicons-megaphone',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'post',
		'show_in_rest'          => true, // Gutenberg Editor support
	);

	register_post_type( 'headline', $args );
}
add_action( 'init', 'my_theme_register_cpts', 0 );
