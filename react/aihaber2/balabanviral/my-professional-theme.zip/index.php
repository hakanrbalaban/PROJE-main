<?php
/**
 * Main Template File (index.php)
 *
 * @package My_Professional_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<main id="primary" class="site-main container">

	<?php if ( ( is_front_page() || is_home() ) && get_theme_mod( 'my_theme_show_hero', true ) ) : ?>
		<!-- Hero Headline Section -->
		<section class="hero-section">
			<?php
			$hero_query = new WP_Query(
				array(
					'posts_per_page'      => 1,
					'ignore_sticky_posts' => 1,
				)
			);

			if ( $hero_query->have_posts() ) :
				while ( $hero_query->have_posts() ) :
					$hero_query->the_post();
					?>
					<div class="headline-slider-card">
						<?php if ( has_post_thumbnail() ) : ?>
							<?php the_post_thumbnail( 'my-theme-slider', array( 'class' => 'slider-image-bg' ) ); ?>
						<?php else : ?>
							<img src="<?php echo esc_url( my_theme_get_fallback_image() ); ?>" class="slider-image-bg" alt="<?php the_title_attribute(); ?>" />
						<?php endif; ?>
						<div class="slider-overlay"></div>
						<div class="slider-content">
							<?php my_theme_category_badge(); ?>
							<h2 class="slider-title">
								<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
							</h2>
							<div class="slider-meta">
								<?php my_theme_posted_by(); ?>
								<?php my_theme_posted_on(); ?>
								<span>⏱️ <?php echo esc_html( my_theme_estimate_reading_time( get_the_ID() ) ); ?> dk okuma</span>
							</div>
						</div>
					</div>
					<?php
				endwhile;
				wp_reset_postdata();
			endif;
			?>
		</section>
	<?php endif; ?>

	<!-- Main Layout: Grid Content + Sidebar -->
	<div class="layout-grid">
		<div class="content-area">
			<?php if ( have_posts() ) : ?>

				<div class="posts-grid">
					<?php
					while ( have_posts() ) :
						the_post();
						get_template_part( 'template-parts/post/content', get_post_format() );
					endwhile;
					?>
				</div>

				<div class="pagination-nav">
					<?php
					the_posts_pagination(
						array(
							'prev_text'          => '← ' . __( 'Önceki', 'my-theme' ),
							'next_text'          => __( 'Sonraki', 'my-theme' ) . ' →',
							'before_page_number' => '',
						)
					);
					?>
				</div>

			<?php else : ?>

				<?php get_template_part( 'template-parts/post/content', 'none' ); ?>

			<?php endif; ?>
		</div>

		<!-- Sidebar Area -->
		<aside class="site-sidebar">
			<?php
			if ( is_active_sidebar( 'sidebar-1' ) ) {
				dynamic_sidebar( 'sidebar-1' );
			} else {
				// Default fallback widgets if sidebar is empty
				?>
				<div class="widget">
					<h3 class="widget-title">📌 <?php esc_html_e( 'Popüler Haberler', 'my-theme' ); ?></h3>
					<ul>
						<?php
						$pop_query = new WP_Query(
							array(
								'posts_per_page' => 5,
								'orderby'        => 'comment_count',
							)
						);
						if ( $pop_query->have_posts() ) :
							while ( $pop_query->have_posts() ) :
								$pop_query->the_post();
								?>
								<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
								<?php
							endwhile;
							wp_reset_postdata();
						endif;
						?>
					</ul>
				</div>
			<?php } ?>
		</aside>
	</div>

</main>

<?php
get_footer();
