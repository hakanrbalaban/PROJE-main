<?php
/**
 * Template part for displaying posts in grid layout
 *
 * @package My_Professional_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'post-card' ); ?>>
	<div class="post-card-thumb">
		<a href="<?php the_permalink(); ?>">
			<?php my_theme_post_thumbnail( 'my-theme-grid' ); ?>
		</a>
	</div>

	<div class="post-card-body">
		<div class="post-card-meta">
			<?php my_theme_category_badge(); ?>
		</div>

		<h2 class="post-card-title">
			<a href="<?php the_permalink(); ?>" rel="bookmark">
				<?php the_title(); ?>
			</a>
		</h2>

		<div class="post-card-excerpt">
			<?php the_excerpt(); ?>
		</div>

		<div class="post-card-footer">
			<?php my_theme_posted_on(); ?>
			<span class="read-time">⏱️ <?php echo esc_html( my_theme_estimate_reading_time( get_the_ID() ) ); ?> dk</span>
		</div>
	</div>
</article>
