<?php
/**
 * Template part for displaying single post content
 *
 * @package My_Professional_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Track view count.
my_theme_set_post_views( get_the_ID() );
?>

<article id="post-<?php the_ID(); ?>" <?php post_class( 'single-post-wrapper' ); ?>>
	<header class="single-post-header">
		<div class="single-post-category">
			<?php my_theme_category_badge(); ?>
		</div>

		<h1 class="single-post-title"><?php the_title(); ?></h1>

		<div class="single-post-meta">
			<?php my_theme_posted_by(); ?>
			<?php my_theme_posted_on(); ?>
			<span class="read-time">⏱️ <?php echo esc_html( my_theme_estimate_reading_time( get_the_ID() ) ); ?> dk okuma</span>
			<span class="views-count">👁️ <?php echo esc_html( my_theme_get_post_views( get_the_ID() ) ); ?> okunma</span>
		</div>
	</header>

	<?php if ( has_post_thumbnail() ) : ?>
		<div class="featured-media-wrapper">
			<?php the_post_thumbnail( 'my-theme-slider' ); ?>
		</div>
	<?php endif; ?>

	<div class="entry-content">
		<?php
		the_content();

		wp_link_pages(
			array(
				'before' => '<div class="page-links">' . esc_html__( 'Sayfalar:', 'my-theme' ),
				'after'  => '</div>',
			)
		);
		?>
	</div>

	<!-- Interactive Reaction Bar -->
	<div class="reaction-bar">
		<button type="button" class="reaction-btn" data-reaction="fire">
			🔥 Yangın <span class="count">12</span>
		</button>
		<button type="button" class="reaction-btn" data-reaction="heart">
			❤️ Harika <span class="count">24</span>
		</button>
		<button type="button" class="reaction-btn" data-reaction="mindblown">
			🤯 İnanılmaz <span class="count">8</span>
		</button>
		<button type="button" class="reaction-btn btn-copy-link" data-url="<?php echo esc_url( get_permalink() ); ?>">
			🔗 Bağlantıyı Kopyala
		</button>
	</div>

	<footer class="entry-footer">
		<?php
		$tags_list = get_the_tag_list( '', esc_html_x( ', ', 'list item separator', 'my-theme' ) );
		if ( $tags_list ) {
			/* translators: 1: list of tags. */
			printf( '<div class="tags-links">🏷️ ' . esc_html__( 'Etiketler: %1$s', 'my-theme' ) . '</div>', $tags_list ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		?>
	</footer>
</article>
