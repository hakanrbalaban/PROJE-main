<?php
/**
 * Theme Bootstrap and Module Loader
 *
 * @package My_Professional_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Define Theme Constants
 */
define( 'MY_THEME_VERSION', '1.0.0' );
define( 'MY_THEME_DIR', get_template_directory() );
define( 'MY_THEME_URI', get_template_directory_uri() );

/**
 * Require Core Inc Files
 */
require_once MY_THEME_DIR . '/inc/class-theme-setup.php';
require_once MY_THEME_DIR . '/inc/enqueue.php';
require_once MY_THEME_DIR . '/inc/helpers.php';
require_once MY_THEME_DIR . '/inc/hooks.php';
require_once MY_THEME_DIR . '/inc/template-tags.php';
require_once MY_THEME_DIR . '/inc/customizer.php';
require_once MY_THEME_DIR . '/inc/custom-post-types.php';
