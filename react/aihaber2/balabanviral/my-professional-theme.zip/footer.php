<?php
/**
 * The Footer template file
 *
 * @package My_Professional_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

	</div><!-- #content -->

	<!-- Site Footer -->
	<footer id="colophon" class="site-footer">
		<div class="container">
			<?php if ( is_active_sidebar( 'footer-1' ) || is_active_sidebar( 'footer-2' ) || is_active_sidebar( 'footer-3' ) ) : ?>
				<div class="footer-widgets">
					<div class="footer-widget-col">
						<?php dynamic_sidebar( 'footer-1' ); ?>
					</div>
					<div class="footer-widget-col">
						<?php dynamic_sidebar( 'footer-2' ); ?>
					</div>
					<div class="footer-widget-col">
						<?php dynamic_sidebar( 'footer-3' ); ?>
					</div>
				</div>
			<?php endif; ?>

			<?php get_template_part( 'template-parts/footer/site-info' ); ?>
		</div>
	</footer>
</div><!-- #page -->

<!-- Search Overlay Modal -->
<div class="search-modal">
	<div class="search-modal-inner">
		<button class="search-modal-close" aria-label="<?php esc_attr_e( 'Aramayı Kapat', 'my-theme' ); ?>">&times;</button>
		<?php get_search_form(); ?>
	</div>
</div>

<?php wp_footer(); ?>

</body>
</html>
