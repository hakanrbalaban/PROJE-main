<?php
/**
 * The Header template file
 *
 * @package My_Professional_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e( 'İçeriğe Atla', 'my-theme' ); ?></a>

	<!-- Header Area -->
	<header id="masthead" class="site-header">
		<div class="container header-wrapper">
			<!-- Site Branding (Logo/Title) -->
			<?php get_template_part( 'template-parts/header/site-branding' ); ?>

			<!-- Primary Navigation Menu -->
			<nav id="site-navigation" class="primary-nav" aria-label="<?php esc_attr_e( 'Ana Menü', 'my-theme' ); ?>">
				<?php
				wp_nav_menu(
					array(
						'theme_location' => 'primary',
						'menu_id'        => 'primary-menu',
						'fallback_cb'    => false,
					)
				);
				?>
			</nav>

			<!-- Header Actions -->
			<div class="header-actions">
				<button class="btn-search-trigger" aria-label="<?php esc_attr_e( 'Arama Yap', 'my-theme' ); ?>">
					🔍 <span><?php esc_html_e( 'Ara', 'my-theme' ); ?></span>
				</button>
				<button class="mobile-nav-toggle" aria-label="<?php esc_attr_e( 'Menüyü Aç', 'my-theme' ); ?>">
					☰
				</button>
			</div>
		</div>
	</header>

	<!-- Mobile Drawer Menu -->
	<div class="mobile-drawer">
		<div class="mobile-drawer-header">
			<span class="site-title"><?php bloginfo( 'name' ); ?></span>
			<button class="mobile-drawer-close" aria-label="<?php esc_attr_e( 'Menüyü Kapat', 'my-theme' ); ?>">&times;</button>
		</div>
		<nav class="mobile-nav">
			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'primary',
					'fallback_cb'    => false,
				)
			);
			?>
		</nav>
	</div>

	<!-- Headline Ticker Bar (Homepage Only) -->
	<?php if ( is_front_page() || is_home() ) : ?>
		<div class="headline-ticker">
			<div class="container ticker-wrapper">
				<span class="ticker-badge"><?php echo esc_html( get_theme_mod( 'my_theme_ticker_label', __( 'Öne Çıkanlar', 'my-theme' ) ) ); ?></span>
				<div class="ticker-content">
					<?php
					$ticker_query = new WP_Query(
						array(
							'posts_per_page' => 5,
							'post_status'    => 'publish',
						)
					);
					if ( $ticker_query->have_posts() ) :
						while ( $ticker_query->have_posts() ) :
							$ticker_query->the_post();
							?>
							<a href="<?php the_permalink(); ?>" class="ticker-item">
								🔥 <?php the_title(); ?>
							</a>
							<?php
						endwhile;
						wp_reset_postdata();
					endif;
					?>
				</div>
			</div>
		</div>
	<?php endif; ?>

	<div id="content" class="site-content">
