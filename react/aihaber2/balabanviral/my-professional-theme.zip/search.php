<?php
/**
 * Search Results Template File (search.php)
 *
 * @package My_Professional_Theme
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>

<main id="primary" class="site-main container">
	<header class="page-header widget" style="margin-bottom: 2rem;">
		<h1 class="page-title single-post-title" style="margin:0;">
			<?php
			/* translators: %s: search query. */
			printf( esc_html__( 'Arama Sonuçları: %s', 'my-theme' ), '<span>' . get_search_query() . '</span>' );
			?>
		</h1>
	</header>

	<div class="layout-grid">
		<div class="content-area">
			<?php if ( have_posts() ) : ?>

				<div class="posts-grid">
					<?php
					while ( have_posts() ) :
						the_post();
						get_template_part( 'template-parts/post/content', get_post_format() );
					endwhile;
					?>
				</div>

				<div class="pagination-nav">
					<?php
					the_posts_pagination(
						array(
							'prev_text' => '← ' . __( 'Önceki', 'my-theme' ),
							'next_text' => __( 'Sonraki', 'my-theme' ) . ' →',
						)
					);
					?>
				</div>

			<?php else : ?>

				<?php get_template_part( 'template-parts/post/content', 'none' ); ?>

			<?php endif; ?>
		</div>

		<!-- Sidebar -->
		<aside class="site-sidebar">
			<?php
			if ( is_active_sidebar( 'sidebar-1' ) ) {
				dynamic_sidebar( 'sidebar-1' );
			}
			?>
		</aside>
	</div>
</main>

<?php
get_footer();
